/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gym;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;



public class MyConnection {
      public static boolean getConnection(){
     
         final String cs = "jdbc:mysql://localhost:3306/java_login_register";
         final String user = "root";
         final String pass = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
             try (Connection con = DriverManager.getConnection(cs, user, pass)) {
                 PreparedStatement ps=con.prepareStatement("INSERT INTO register (u_fname, u_lname, u_uname, u_pass, u_bdate, u_address) VALUES (?,?,?,?,?,?)");
                 ps.setString(1, "hd");
                 ps.setString(2, "hfd");
                 ps.setString(3, "hfsd");
                 ps.setString(4, "hdsd");
                 ps.setString(5, "hfd");
                 ps.setString(6, "hdgdg");
                 ps.execute();
             }
            System.out.println("ierueiruje");
             return true;
        } 
        catch (ClassNotFoundException | SQLException ex)
        {
            System.out.println(ex);
             return false;
        }
      }
        public static void main(String args[]) {
            getConnection();
        }
       
    }

    
   
    

